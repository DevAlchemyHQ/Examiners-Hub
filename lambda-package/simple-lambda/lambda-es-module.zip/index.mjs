import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import JSZip from 'jszip';

// Configure AWS S3 client
const s3Client = new S3Client({ region: 'eu-west-2' });

export const handler = async (event) => {
  try {
    console.log('Lambda function started');
    console.log('Event:', JSON.stringify(event, null, 2));

    // Parse the incoming data
    const { selectedImages, formData } = event;

    if (!selectedImages || !Array.isArray(selectedImages)) {
      throw new Error('No selected images provided');
    }

    console.log(`Processing ${selectedImages.length} images`);

    // Create a new ZIP file
    const zip = new JSZip();

    // Process each selected image
    for (const image of selectedImages) {
      try {
        console.log(`Processing image: ${image.filename || image.id}`);

        // Get image from S3 using AWS SDK v3
        const getObjectCommand = new GetObjectCommand({
          Bucket: process.env.S3_BUCKET_NAME,
          Key: image.s3Key
        });

        const response = await s3Client.send(getObjectCommand);
        
        // Convert stream to buffer
        const chunks = [];
        for await (const chunk of response.Body) {
          chunks.push(chunk);
        }
        const buffer = Buffer.concat(chunks);

        // Add to ZIP
        zip.file(image.filename || `image-${image.id}.jpg`, buffer);
        console.log(`Added ${image.filename} to ZIP`);

      } catch (error) {
        console.error(`Error processing image ${image.filename}:`, error);
        // Continue with other images
      }
    }

    // Generate ZIP file
    const zipBuffer = await zip.generateAsync({ type: 'nodebuffer' });
    console.log(`Generated ZIP file: ${zipBuffer.length} bytes`);

    // Create unique filename
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const projectName = formData?.projectName || 'download';
    const zipFileName = `${projectName}-${timestamp}.zip`;

    // Upload ZIP to S3
    const putObjectCommand = new PutObjectCommand({
      Bucket: process.env.S3_BUCKET_NAME,
      Key: `downloads/${zipFileName}`,
      Body: zipBuffer,
      ContentType: 'application/zip'
    });

    await s3Client.send(putObjectCommand);
    console.log(`Uploaded ZIP to S3: downloads/${zipFileName}`);

    // Generate presigned URL for download
    const getSignedUrlCommand = new GetObjectCommand({
      Bucket: process.env.S3_BUCKET_NAME,
      Key: `downloads/${zipFileName}`
    });

    const presignedUrl = await getSignedUrl(s3Client, getSignedUrlCommand, { expiresIn: 3600 });
    console.log('Generated presigned URL');

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      body: JSON.stringify({
        success: true,
        downloadUrl: presignedUrl,
        filename: zipFileName,
        message: `Successfully created ZIP with ${selectedImages.length} images`
      })
    };

  } catch (error) {
    console.error('Lambda function error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      body: JSON.stringify({
        success: false,
        error: error.message,
        message: 'Failed to create ZIP file'
      })
    };
  }
};
